<?php
header('Access-Control-Allow-Origin: *');
$servername = "208.91.199.11";
$username = "jvega";
$password = "2X7nl2@u";
$dbname = "BD_ListaSuperMX";

//$servername = "localhost";
//$username = "root";
//$password = "";
//$dbname = "BD_ListaSuperMX";

?>